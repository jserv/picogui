#!/usr/bin/perl
use PicoGUI;

RegisterApp(-name => NewString("App"),-side=>left);

EventLoop;
