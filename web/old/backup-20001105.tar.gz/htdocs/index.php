<?php require "lib.php"; beginpage("News"); 
newsbox("PicoGUI News","/home/groups/pgui/news");
endpage(); ?>
