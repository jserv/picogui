<?php require "lib.php"; beginpage("About the logo"); 
box("PicoGUI's Logo");
?>

<table bgcolor="#000000" width="100%" border=2 cellspacing=2 cellpadding=8>
<tr><td align=center>
<img src="/gfx/logo-micah2-big.png" width=344 height=224></td></tr></table><p>

This is PicoGUI's current logo. If you're feeling creative, feel free to
make your own. I'm keeping "extra" logos in the CVS, as well as displaying
them below. Other file sizes/formats (including Gimp XCF) are in the CVS.
<p><ul>

<li>
This is the first logo I designed. I like the current one better, but this
has fewer colors and has a much smaller file size:<p>
<center><img src="/gfx/logo-micah1-big.png" width=440 height=205></center>
</li>

</ul>
<?php
endbox();
endpage(); ?>
