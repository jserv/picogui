#!/bin/sh
cd /home/groups/pgui/cvsw
cvs -dmicahjd@cvs1:/cvsroot/pgui co cli_c
cvs -dmicahjd@cvs1:/cvsroot/pgui co cli_perl
cvs -dmicahjd@cvs1:/cvsroot/pgui co doc
cvs -dmicahjd@cvs1:/cvsroot/pgui co images
cvs -dmicahjd@cvs1:/cvsroot/pgui co pgserver
cvs -dmicahjd@cvs1:/cvsroot/pgui co themetools

